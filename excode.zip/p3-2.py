def min_max(numbers):
    """
    정수 리스트를 받아 (최솟값, 최댓값) 튜플을 반환하는 함수
    """
    min_val = numbers[0]
    max_val = numbers[0]

    for num in numbers[1:]:
        if num < min_val:
            min_val = num
        if num > max_val:
            max_val = num

    return (min_val, max_val)


# 사용자로부터 정수들 입력받기
user_input = input("정수들을 공백으로 구분하여 입력하세요: ").split()

# 문자열 리스트를 정수 리스트로 변환
int_list = [int(x) for x in user_input]

if int_list:
    # min_max 함수 호출
    result_min, result_max = min_max(int_list)

    print(f"min 값: {result_min}")
    print(f"max 값: {result_max}")
    print(f"반환된 튜플: {(result_min, result_max)}")
else:
    print("입력된 정수가 없습니다.")