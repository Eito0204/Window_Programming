import os

while True:
    # 1. 사용자로부터 파일명 입력받기
    filename = input("읽을 파일명을 입력하세요 (종료하려면 'q' 입력): ").strip()
    
    if filename.lower() == 'q':
        print("프로그램을 종료합니다.")
        break

    try:
        # 파일 열기 및 읽기
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            
        # 1) 라인 번호를 붙여 콘솔에 출력
        print("\n--- [화면 출력] ---")
        numbered_lines = []
        for idx, line in enumerate(lines, start=1):
            numbered_line = f"{idx} {line}"
            numbered_lines.append(numbered_line)
            print(numbered_line, end="")
        print("\n------------------")

        # 2) 라인 번호를 붙여 ***.sav 형식의 파일로 저장
        # (예: test.txt -> test.sav, sample -> sample.sav)
        base_name, _ = os.path.splitext(filename)
        save_filename = f"{base_name}.sav"

        with open(save_filename, 'w', encoding='utf-8') as f_out:
            f_out.writelines(numbered_lines)

        print(f"'{save_filename}' 파일로 저장이 완료되었습니다.\n")
        break  # 성공적으로 처리 후 종료 (필요 시 계속 반복하도록 유지 가능)

    except FileNotFoundError:
        print(f"오류: '{filename}' 파일을 찾을 수 없습니다. 다시 시도해 주세요.\n")