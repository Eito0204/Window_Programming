#2-3
n = int(input("1~100 사이의 자연수를 입력하세요: "))

if n % 2 ==1:
    print(f"{n}은(는) 홀수입니다.")
else:
    print(f"{n}은(는) 짝수입니다.")