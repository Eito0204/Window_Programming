scores = {
    "Kim": [80, 90, 70],
    "Lee": [100, 90, 85],
    "Park": [95, 85, 100]
}

# 1. 각 학생별 평균 점수 딕셔너리 생성
averages = {}
for name, score_list in scores.items():
    averages[name] = sum(score_list) / len(score_list)

print("averages:", averages)

# 2. 평균 점수가 90점 이상인 학생 이름 리스트 생성
names = [name for name, avg in averages.items() if avg >= 90]

print("names:", names)