students = {
    "name": "Kim",
    "math": 80,
    "science": 90
}

#  과목 history, 점수 90 아이템 추가
students["history"] = 90

#  과목 math인 아이템 제거
del students["math"]
# 또는 students.pop("math")

#  과목 science인 아이템의 점수를 100으로 수정
students["science"] = 100

#  history와 science 점수의 평균 계산 및 출력
avg_score = (students["history"] + students["science"]) / 2
print(f"{students['name']}’s average score is {avg_score:.0f}")
