import math
import turtle
import figure  # figure.py 파일이 같은 디렉터리에 있어야 합니다.


class Triangle(figure.Polygon):
    """정삼각형 클래스 (Polygon 상속)"""
    count = 0  # 생성된 Triangle 인스턴스 수를 세기 위한 클래스 변수

    def __init__(self):
        # 정삼각형이므로 부모 클래스(Polygon)에 변의 개수 3을 전달
        super().__init__(3)
        
        # 인스턴스 생성 시 카운트 증가 및 시리얼 번호 부여
        Triangle.count += 1
        self.serial = Triangle.count

    def getArea(self):
        """정삼각형 면적 계산 오버라이드: (sqrt(3) / 4) * a^2"""
        area = (math.sqrt(3) / 4) * (self.sideLen ** 2)
        return area

    def getSerial(self):
        """객체가 몇 번째 생성된 인스턴스인지 반환"""
        return self.serial

    def draw(self):
        """turtle 모듈을 이용하여 삼각형 그리기"""
        turtle.speed(3)
        for _ in range(self.sideNumber):
            turtle.forward(self.sideLen)
            turtle.right(360 / self.sideNumber)  # 360 / 3 = 120도 회전
        
        input("Press any key to stop...")
        turtle.bye()


# --- 요구사항 실행 코드 ---
if __name__ == "__main__":
    # 1. Triangle 객체 생성
    t = Triangle()

    # 2. 한 변의 길이를 300으로 설정
    t.setSideLen(300)

    # 3. 면적 계산 및 출력
    print(f"도형 이름: {t.getShape()}")
    print(f"정삼각형 면적: {t.getArea():.2f}")

    # 4. 몇 번째 객체인지 출력
    print(f"인스턴스 시리얼 번호: {t.getSerial()}")

    # 5. 삼각형 그리기
    t.draw()