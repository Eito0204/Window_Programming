def calc(*args, op="+"):
    if not args:
        return 0

    if op == "+":
        result = 0
        for num in args:
            result += num
        return result

    elif op == "*":
        result = 1
        for num in args:
            result *= num
        return result

    else:
        raise ValueError("지원하지 않는 연산자입니다. ('+' 또는 '*'만 가능)")


# 실행 예시 테스트
print(calc(1, 1, 4, op="+"))  # 6
print(calc(1, 2, op="*"))     # 2