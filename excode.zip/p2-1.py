#2-1
list1 = [1, 0, 1]
list2 = [1, 1, 2]

total = list1[0] * list2[0] + list1[1] * list2[1] + list1[2] * list2[2]

print(f"{list1} * {list2} = {total}")