#1-3

import math
# 1
a, b, c = 3, 4, 5
ans1 = 1 / (1 + (a / b) + c)
print(f"1번 답: {ans1}")

# 2
a, b, c = 1, 1, -6
root1 = (-b + math.sqrt(b**2 - 4*a*c)) / (2 * a)
root2 = (-b - math.sqrt(b**2 - 4*a*c)) / (2 * a)
print(f"2번 답: 근 1 = {root1}, 근 2 = {root2}")

# 3
r = 5
area = math.pi * (r ** 2)
print(f"3번 답: {area}")

# 4
beta, g = 2.0, 3.2
ans4 = beta * math.exp(-g)
print(f"4번 답: {ans4}")

# 5
x, mu, rho = 0, 1.5, 2.0
ans5 = (1 / math.sqrt(2 * math.pi * rho)) * math.exp(((x - mu)**2) / (2 * (rho**2)))
print(f"5번 답: {ans5}")