def do_operation(func, x, y):
    return func(x, y)

def add(a, b):
    return a + b

def sub(a,b):
    return a - b

result_add = do_operation(add, 2, 3)
result_sub = do_operation(sub, 5, 2)

print(f"do_operation(Add, 2, 3) -> {result_add}")
print(f"do_operation(sub, 5, 2) -> {result_sub}")

# lambda 함수로 정의하여 사용
add_lambda = lambda a, b: a + b
sub_lambda = lambda a, b: a - b

result_lambda = lambda a, b: a + b
result_lambda = lambda a, b: a - b

result_lambda_add = do_operation(add_lambda, 2, 3)
result_lambda_sub = do_operation(sub_lambda, 5, 2)

print(f"do_operation(add_lambda, 2, 3) -> {result_lambda_add}")      # 5 출력
print(f"do_operation(sub_lambda, 5, 2) -> {result_lambda_sub}")      # 3 출력