# 빈 리스트 num 만들기
num = []
print(f"1. 빈 리스트 생성: {num}")

# 리스트에 10, 20, 30 추가
num.append(10)
num.append(20)
num.append(30)
# 또는 num.extend([10, 20, 30])
print(f"2.10, 20, 30 추가: {num}")

# 20과 30 사이에 40 추가
num.insert(2, 40)
print(f"3. 20과 30 사이에 40 추가: {num}")

# 마지막 요소 삭제하고 출력
deleted_item = num.pop()
print(f"4. 마지막 요소 삭제: {deleted_item}")
print(f"   삭제 후 리스트: {num}")

# 요소들의 합을 구하여 출력
total = sum(num)
print(f"6. 요소들의 합: {total}")