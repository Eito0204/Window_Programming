#2-2
# 1
student_dic = {}

while True:
    student_id = input("학번을 입력하세요(종료: Fin!): ")
    if student_id == "Fin!":
        break
    
    name = input("이름을 입력하세요: ")
    student_dic[student_id] = name

print("생성된 학생 정보:", student_dic)

# 2,3
while True:
    dic_id = input("조회할 학번을 입력하세요: ")
    
    if dic_id == "Quit!":
        break
    
    if dic_id in student_dic:
        print(f"이름: {student_dic[dic_id]}")
    else:
        print("not found!")