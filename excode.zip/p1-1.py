#1-1
s1, s2 = input("두 정수를 입력하세요: ").split()

num1 = int(s1)
num2 = int(s2)

print(f"{num1} + {num2} = {num1 + num2}")
print(f"{num1} - {num2} = {num1 - num2}")
print(f"{num1} * {num2} = {num1 * num2}")
print(f"{num1} / {num2} = {num1 / num2}")