text = "window programm"

result = [ch for ch in text if ch not in "aeiouAEIOU"]

print("생성된 리스트")
print(result)