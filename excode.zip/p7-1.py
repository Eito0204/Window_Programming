# str = "WindowProgramming"

# print(str[1:4])
# print(str[9:])
# print(str[2:8:2])
# print(str[-1:10:-1])

# 위 코드의 출력 결과는
# ind
# gramming
# ndo
# gnimmar

s = "WindowProgramming"

tup = tuple(s)

print(tup[1:4])
print(tup[9:])
print(tup[2:8:2])
print(tup[-1:10:-1])