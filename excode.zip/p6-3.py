from abc import ABC, abstractmethod


# 1. 추상 클래스 Polygon 정의
class Polygon(ABC):
    shapes = {3: 'triangle', 4: 'rectangle', 5: 'pentagon'}

    def __init__(self, numSide):
        self.sideNumber = numSide
        self.sideLen = 0

    def setSideLen(self, sideLen):
        self.sideLen = float(sideLen)

    def getShape(self):
        return Polygon.shapes[self.sideNumber]

    # 추상 메서드로 선언: 자식 클래스에서 반드시 오버라이딩해야 함
    @abstractmethod
    def getArea(self):
        pass


# 2. getArea()를 구현하지 않은 불완전한 자식 클래스
class IncompleteShape(Polygon):
    def __init__(self):
        super().__init__(4)
    # getArea() 메서드를 정의하지 않음


# 3. getArea()를 올바르게 구현한 정상적인 자식 클래스
class Rectangle(Polygon):
    def __init__(self):
        super().__init__(4)

    def getArea(self):
        return self.sideLen * self.sideLen


# --- 테스트 및 확인 ---

# [확인 1] getArea를 오버라이딩하지 않은 자식 클래스의 인스턴스 생성 시도
print("1. 추상 메서드를 미구현한 클래스 객체 생성 테스트:")
try:
    bad_obj = IncompleteShape()
    print("객체 생성 성공")
except TypeError as e:
    print(f"객체 생성 실패 (TypeError 발생): {e}")

print()

# [확인 2] getArea를 정상 구현한 자식 클래스의 인스턴스 생성
print("2. 추상 메서드를 구현한 클래스 객체 생성 테스트:")
rect = Rectangle()
rect.setSideLen(10)
print(f"도형: {rect.getShape()}")
print(f"면적: {rect.getArea()}")