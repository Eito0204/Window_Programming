words = ["tiger", "lion", "elephant", "cat", "horse"]

# 길이가 5 이상인 단어만 추출
result = [word for word in words if len(word) >= 5]

print("생성된 리스트")
print(result)