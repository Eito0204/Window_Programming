#2-6
n = int(input("1~100 사이의 자연수를 입력하세요: "))

if n > 1:
    num = True
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            num = False
            break
    
    if num:
        print(f"{n}은 소수입니다.")