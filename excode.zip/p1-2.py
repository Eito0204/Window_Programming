# #1
# x = 10
# def test():
# print(x)
# test()
# print(x)

# #2
# x = 10
# def test():
# x = 20
# print(x)
# test()
# print(x)

# #3
# x = 10
# def outer():
# x = 20
# def inner():
# x = 30
# print("A:", x)
# inner()
# print("B:", x)
# outer()
# print("C:", x)

# #4
# x = 10
# def test():
# print(x)
# x = 20
# test()
# print(x)