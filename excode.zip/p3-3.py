def count_vowel(text):
    """문자열에서 모음(a, e, i, o, u)의 개수를 세어 반환하는 함수"""
    vowels = "aeiouAEIOU"
    count = 0
    for char in text:
        if char in vowels:
            count += 1
    return count


# 사용자로부터 문자열 입력받기
user_text = input("문자열을 입력하세요: ")

# count_vowel 함수 호출 및 결과 출력
result = count_vowel(user_text)
print(f"모음의 개수: {result}")