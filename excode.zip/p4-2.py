while True:
    filename = input("읽을 파일명을 입력하세요 (종료하려면 'q' 입력): ").strip()
    
    if filename.lower() == 'q':
        print("프로그램을 종료합니다.")
        break

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()

        # 1. 라인 수 (\n으로 분리된 줄의 수)
        lines = text.splitlines()
        num_lines = len(lines)

        # 2. 단어 수 (공백으로 분리된 문자열의 수)
        words = text.split()
        num_words = len(words)

        # 3. 공백을 제외한 글자 수 (스페이스, 탭, 줄바꿈 등 제외)
        num_chars = sum(len(ch) for ch in text if not ch.isspace())

        # 출력 형식
        print(f"characters : {num_chars}")
        print(f"words : {num_words}")
        print(f"lines : {num_lines}")
        break

    except FileNotFoundError:
        print(f"오류: '{filename}' 파일을 찾을 수 없습니다. 다시 시도해 주세요.\n")