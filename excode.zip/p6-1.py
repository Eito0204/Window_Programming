# ==========================================
# 1. Calc 클래스 및 테스트
# ==========================================
class Calc:
    # 생성된 인스턴스 수를 누적 기록하는 클래스 변수
    count = 0

    def __init__(self, a, b):
        self.a = a
        self.b = b
        # 인스턴스가 생성될 때마다 카운트를 증가시키고 시리얼 번호로 저장
        Calc.count += 1
        self.serial = Calc.count

    def add(self):
        """두 정수의 합 반환"""
        return self.a + self.b

    def sub(self):
        """두 정수의 차 반환"""
        return self.a - self.b

    def getSerial(self):
        """객체가 몇 번째 생성된 인스턴스인지 반환"""
        return self.serial


print("=== [1. Calc 테스트] ===")
a = 3
b = 2
calc1 = Calc(a, b)
print(f'{a} + {b} = {calc1.add()}')
print(f'{a} - {b} = {calc1.sub()}')

calc2 = Calc(3, 4)
print(f'{3} + {4} = {calc2.add()}')
print(f'{3} + {4} = {calc2.sub()}')

print(f'Serial of calc1: {calc1.getSerial()}')
print(f'Serial of calc2: {calc2.getSerial()}')
print()


# ==========================================
# 2. Polygon 부모 클래스
# ==========================================
class Polygon:
    shapes = {3: 'triangle', 4: 'rectangle', 5: 'pentagon'}

    def __init__(self, numSide):
        self.sideNumber = numSide
        self.sideLen = 0

    def setSideLen(self, sideLen):
        self.sideLen = float(sideLen)

    def getShape(self):
        return Polygon.shapes[self.sideNumber]

    def getArea(self):
        pass


print("=== [2. Polygon 테스트] ===")
print('Shape: {}'.format(Polygon.shapes[5]))

p = Polygon(4)
print("number of sides : {}".format(p.sideNumber))
print("length of side : {}".format(p.sideLen))

sideLen = float(input("Enter side length for Polygon: "))
p.setSideLen(sideLen)
print("length of side : {}".format(p.sideLen))

print("Shape name:", p.getShape())
print("Polygon area:", p.getArea())  # pass이므로 None 출력
print()


# ==========================================
# 3. Polygon을 상속받는 Rectangle 자식 클래스
# ==========================================
# 같은 파일이므로 figure.Polygon이 아니라 바로 Polygon 상속
class Rectangle(Polygon):
    '''square rectangle class'''

    def __init__(self):
        # 사각형이므로 변의 개수 4를 부모 생성자에 전달
        super().__init__(4)

    def getArea(self):
        # 정사각형 넓이 계산 메서드 오버라이딩
        return self.sideLen * self.sideLen


print("=== [3. Rectangle 상속 테스트] ===")
r = Rectangle()
print("Shape name:", r.getShape())  # 부모의 getShape() 호출 -> 'rectangle'

sideLen = float(input("Enter side length for Rectangle: "))
r.setSideLen(sideLen)
print("Rectangle area:", r.getArea())  # 자식의 getArea() 호출