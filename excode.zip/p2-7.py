import random

# 어휘 리스트
words = ["hangman", "python", "banana", "apple", "computer"]

while True:
    # 1. 단어 랜덤 선택 및 초기 설정
    secret_word = random.choice(words)
    guessed_letters = []  # 맞힌 글자들을 저장할 리스트
    trials = 5            # 허용할 오답 횟수

    print("\n=== 행맨 게임 시작 ===")
    
    # 단어의 글자 수만큼 초기 밑줄 출력
    current_display = ["_" for _ in secret_word]
    print(" ".join(current_display))

    # 2. 게임 라운드 진행
    while trials > 0:
        guess = input("\n글자를 입력하세요: ").lower()

        # 이미 맞힌 글자를 다시 입력한 경우
        if guess in guessed_letters:
            print("이미 입력했던 글자입니다.")
            continue

        # 단어에 해당 글자가 있는 경우
        if guess in secret_word:
            guessed_letters.append(guess)
        else:
            # 단어에 글자가 없는 경우
            trials -= 1
            print(f"Nope! {trials} trials left")

        # 현재 상태 갱신 (_ 또는 맞힌 글자)
        current_display = [ch if ch in guessed_letters else "_" for ch in secret_word]
        print(" ".join(current_display))

        # 단어를 모두 맞춘 경우 확인
        if "_" not in current_display:
            print("\nGood Job!")
            break
    else:
        # 기회를 모두 소진하여 while문이 끝난 경우
        print(f"\nFail! 정답은 '{secret_word}'였습니다.")

    # 3. 옵션: 게임 재진행 여부 확인
    play_again = input("\n게임을 계속 하시겠습니까? (y/n): ").lower()
    if play_again != "y":
        print("게임을 종료합니다.")
        break