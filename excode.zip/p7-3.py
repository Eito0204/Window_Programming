numbers = [1, 2, 2, 5, 3, 4, 3, 5, 1, 6]

# 중복을 제거한 원소들을 담을 새 리스트 생성
unique_numbers = []

# 리스트 순환
for n in numbers:
    # 아직 결과 리스트에 없는 숫자인지 확인 (not in)
    if n not in unique_numbers:
        unique_numbers.append(n)

print(f"결과 => {unique_numbers}")